@echo off
cd /d "%~dp0"
py -3 "System Files\Object_Factory_v1.3.py"
if errorlevel 1 python "System Files\Object_Factory_v1.3.py"
pause
