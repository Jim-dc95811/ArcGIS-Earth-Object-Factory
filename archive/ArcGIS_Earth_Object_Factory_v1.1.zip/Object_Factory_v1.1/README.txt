ArcGIS Earth Object Factory v1.1
================================

Create geographic objects, object sets, a Sky Compass and Earth Beacons for
ArcGIS Earth without writing KML by hand.

Requirements: Windows Python 3 with Tkinter (the standard python.org install).
No other packages are needed.


START
-----
Keep these together in one folder:
   Object_Factory_v1.1.py
   Run_Object_Factory.bat
   icons\

Double-click Run_Object_Factory.bat.


COORDINATES - FROM CLIPBOARD
----------------------------
1. In Google Maps, right-click the location. The first line of the menu is
   the coordinate, e.g. 30.40098, -81.93471. Click it to copy it.
2. In the factory, click From Clipboard.
3. Read the line under the button, e.g.
      Read as Latitude 30.400980 N, Longitude 81.934710 W (...)
   and check it is the place you meant.
4. Create the object.

From Clipboard also understands N/S/E/W letters (30.4009768°N 81.9347098°W)
and degrees-minutes-seconds (30°24'03.5"N 81°56'05.0"W). Coordinates can
always be typed in by hand instead.


TABS
----
Objects      One PNG object: preset or custom PNG, altitude and altitude mode,
             icon scale, optional tether and label, Info popup or No Popup,
             multiline Info text, optional link. Output: KMZ.
Batch        One text/CSV list -> one KMZ object set.
             Shorthand:  type,lat,lon[,alt_m][,name]
             Full:       type|name|lat|lon|alt_m|icon|description|url|link_text|scale|altitude_mode|tether|popup|label
             A blank icon uses the type's preset. Relative icon paths are
             read from beside the list file. Problems are reported with the
             line number, e.g. "Line 4: latitude '30.4O' is not a number."
Sky Compass  Giant N/E/S/W markers around a centre point. Output: KMZ.
Beacon       Tall vertical Earth Beacon line. Output: KML.

Presets: object, helicopter, fuel, bird, hazard, home, staging, water,
firetruck, camera, medical.


FILES
-----
- Your original PNG is never modified. The KMZ gets a working copy no
  larger than 256 px, with aspect ratio and transparency kept.
- If the output file already exists, the factory asks before replacing it.
- If a build fails part-way, the previous file is left untouched.


SAMPLES
-------
sample_objects.txt   full-format list
simple_objects.txt   shorthand list
SAMPLE_*.kmz/kml     example outputs


SELF-TEST
---------
   py -3 Object_Factory_v1.1.py --selftest
Expected: OBJECT FACTORY SELFTEST PASS


NOTE
----
ArcGIS Earth's own information window is large. Keep Info text short, and
use No Popup for purely visual objects.
