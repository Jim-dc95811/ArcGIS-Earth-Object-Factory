EarthStick Beacon Maker 1.0

Creates a vertical KML beacon for ArcGIS Earth.

Coordinate sources:
- Manual latitude / longitude entry
- Windows clipboard
- Current ArcGIS Earth camera position

Clipboard examples:
30.123, -81.456
-81.456 30.123
Latitude: 30.123 Longitude: -81.456

If an unlabeled pair is ambiguous, the program reports how it interpreted
the pair and provides a Swap Lat/Lon button.

Default beacon:
- 100 km tall
- Red
- Line width 6
- relativeToGround KML altitude mode

Run:
Double-click Beacon_Maker.bat

ArcGIS Earth coordinate pickup requires its Automation API to be enabled
at the default local address:
http://localhost:8000
