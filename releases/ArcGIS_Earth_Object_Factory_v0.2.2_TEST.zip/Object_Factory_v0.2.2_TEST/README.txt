ArcGIS Earth Object Factory v0.2.2 TEST
====================================

STATUS
------
This build starts from the accepted-working v0.2 source. The only GUI repair is
that the existing Info text entry is given a fixed visible height so Windows/DPI
layout pressure cannot collapse it. Object/KMZ generation behavior is preserved.
This build is not a final/release version until it is live-tested in ArcGIS Earth.

No installation is required beyond Python with Tkinter (standard Windows Python
install). No Pillow or other third-party packages are required.

V0.2.2 REPAIR SUMMARY
-----------------
- Removed "From ArcGIS Earth" coordinate-source buttons.
- Removed "Swap Lat/Lon" control.
- Removed "Open after creation" option/behavior.
- Objects, Batch, Sky Compass, and Beacon tabs now use larger bold blue tab text.
- Manual coordinate entry remains available.
- "From Clipboard" remains the preferred fast coordinate workflow.
- Proven object, batch, Sky Compass, Beacon, PNG-normalization, popup, and link
  generation behavior is otherwise unchanged.
- Existing Info text entry is now fixed at a visible two-line height.
- Built-in preset list is unchanged: object, helicopter, fuel, bird, hazard, home,
  staging, water, firetruck, camera, medical.

START
-----
Double-click: Run_Object_Factory.bat

TABS
----
1. Objects
   - Generic PNG geographic object
   - Manual coordinates or From Clipboard
   - Presets: object, helicopter, fuel, bird, hazard, home, staging, water,
     firetruck, camera, medical
   - PNG inspection/preview
   - Source PNG is NEVER modified
   - Packaged PNG working copy is automatically normalized to <=256 px max
     dimension while preserving aspect ratio/transparency
   - Smaller icons are not upscaled
   - relativeToGround / absolute / clampToGround
   - Icon scale
   - Optional tether
   - Labels OFF by default
   - Info popup or No Popup
   - Optional clickable hyperlink in Info content
   - KMZ output

2. Batch
   - One simple text/CSV list -> one KMZ object set
   - Preset icons by TYPE
   - Custom relative/absolute PNG paths
   - PNG normalization applies to all packaged icons
   - Duplicate source icons are packaged once and reused
   - Supports links, popup mode, scale, tether, altitude mode, labels
   - Full-header format and kid-simple shorthand format

   Shorthand:
      type,lat,lon[,alt_m][,name]

   Full header:
      type|name|lat|lon|alt_m|icon|description|url|link_text|scale|altitude_mode|tether|popup|label

3. Sky Compass
   - Generates N/E/S/W horizon markers around a center point
   - Center coordinates: manual or From Clipboard
   - Radius, altitude and icon scale are adjustable
   - Output is one KMZ

4. Beacon
   - Accepted Earth Beacon geometry integrated as a factory tab
   - Coordinates: manual or From Clipboard
   - Height, line width, color
   - Output remains KML

COORDINATE WORKFLOW
-------------------
Preferred quick workflow:
1. Find the location in the map/source you are using.
2. Copy its latitude/longitude pair.
3. Click From Clipboard in Object Factory.
4. Verify the displayed Latitude and Longitude.
5. Create the object.

The factory no longer presents coordinate swapping or ArcGIS-camera capture controls.
This keeps placement explicit and avoids accidental location changes while moving the
mouse between ArcGIS Earth and the factory window.

PNG NORMALIZATION NOTE
----------------------
The factory intentionally uses Tkinter's native PNG support so there is no external
dependency. Oversized PNGs are reduced by integer subsampling until the packaged
working copy is <=256 px. The original file remains byte-for-byte untouched.

POPUP NOTE
----------
ArcGIS Earth's native KML info window is larger than desired. Keep Info text concise.
Use No Popup for purely visual objects.

LINK NOTE
---------
The factory can place a standard HTML hyperlink in the object's KML description.

TESTING
-------
Developer self-test command:
   py -3 Object_Factory_v0.2_TEST.py --selftest

Self-test covers:
- oversized/wide PNG normalization and original-file preservation
- single object KMZ
- hyperlink output
- no-popup KML style output
- 100-object batch stress pack
- duplicate icon reuse
- shorthand list parsing
- Sky Compass generation
- Beacon generation

Acceptance rule: do not rename this as a final/release version until live-tested in
ArcGIS Earth.
